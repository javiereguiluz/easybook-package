# LICENSE #

`ca`, `de`, `en`, `es`, `fr`, and `it` hyphen dictionaries were copied from:
http://hg.mozilla.org/mozilla-central/file/47031d2af6d2/intl/locales

`eu` hyphen dictionary was copied from:
http://www.ctan.org/tex-archive/language/hyph-utf8/tex/generic/hyph-utf8/patterns/ptex